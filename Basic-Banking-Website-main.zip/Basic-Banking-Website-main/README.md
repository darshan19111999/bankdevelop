# Basic banking Website
It is a simple transfer of money between multiple users and track every transaction. 
It can show us history of our transactions . 
We can add new users.
We can also check all the customers details.

# Technologies used are :
1)HTML
2)CSS
3)BOOTSTRAP
4)PHP
5)MYSQL
